<?php
include "./header.php";
include "./connection.php";
$query   = "SELECT * FROM vehicles" ;

$execute = mysqli_query($connection  , $query);
$vehicleData = array();
while($rowData = mysqli_fetch_assoc($execute))
{
    $vehicleData[]  = $rowData;
}
echo json_encode($vehicleData) ;

?>