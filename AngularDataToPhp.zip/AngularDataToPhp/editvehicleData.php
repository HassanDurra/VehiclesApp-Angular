<?php
include "./header.php" ;
include "./connection.php" ;

$id       = json_decode(file_get_contents('php://input') , true);

$query    = "SELECT * FROM vehicles where id = '".$id."'" ;
$execute  = mysqli_query($connection  , $query);
$data     = array();

if($execute == true)
{
    while($vehicleData = mysqli_fetch_assoc($execute))
    {
        $data[] = $vehicleData ;
    }
    echo json_encode($data);
}


?>