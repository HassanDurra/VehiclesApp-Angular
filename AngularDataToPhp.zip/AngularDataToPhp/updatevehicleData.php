<?php
include "./header.php";
include "./connection.php";

$data   = json_decode(file_get_contents("php://input") , true);

$updateQuery  = "UPDATE vehicles set `name` = '".$data['VehicleName']."' , `ownername` = '".$data['VehicleOwner']."' , `dateofdelivery` = '".$data['VehicleDate']."' WHERE id = '".$data['VehicleId']."' ";
$execute      = mysqli_query($connection , $updateQuery);

if($execute == true)
{
    $allData = array();

    $getQuery = "SELECT * FROM vehicles";
    $getExe   = mysqli_query($connection , $getQuery);

    while($vehicleData = mysqli_fetch_assoc($getExe))
    {
        $allData[] = $vehicleData;
    }
    echo json_encode($allData) ;
}

?>