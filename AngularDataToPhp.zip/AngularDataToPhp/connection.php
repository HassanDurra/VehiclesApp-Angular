<?php
$host     = "localhost" ;
$password = "";
$user     = "root";
$database = "angulardata";

$connection = mysqli_connect($host, $user, $password ,$database);



?>