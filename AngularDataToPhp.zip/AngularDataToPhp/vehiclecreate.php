<?php
include './header.php';
include './connection.php';

$inputData    = json_decode(file_get_contents("php://input") , true);

$insertQuery  = "INSERT INTO vehicles(`name` , `ownername` , `dateofdelivery`) VALUES
('".$inputData['Vehiclename']."' , '".$inputData['Ownername']."' , '".$inputData['DateofDelivery']."')";

$executeQuery = mysqli_query( $connection , $insertQuery );

if($executeQuery == true)
{
   $getQuery   = "SELECT * FROM vehicles";
   $getResults = array();
   $excute     = mysqli_query($connection , $getQuery);
   while($allData = mysqli_fetch_assoc($excute))
   {
    $getResults[] = $allData ;
   }
   echo json_encode($getResults);
}
else
{
    echo "Failed To Insert Vehicle Data";
}




?>