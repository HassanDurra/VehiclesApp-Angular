<?php
include './header.php';
include './connection.php';

$inputData    = json_decode(file_get_contents("php://input") , true);

$insertQuery  = "INSERT INTO vehicles(`name` , `ownername` , `dateofdelivery`) VALUES
('".$inputData['Vehiclename']."' , '".$inputData['Ownername']."' , '".$inputData['DateofDelivery']."')";

$executeQuery = mysqli_query( $connection , $insertQuery );

if($executeQuery == true)
{
    echo "Vehicle Data Has been Inserted";
}
else
{
    echo "Failed To Insert Vehicle Data";
}




?>