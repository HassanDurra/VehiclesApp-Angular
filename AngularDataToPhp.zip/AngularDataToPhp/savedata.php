<?php

include "./connection.php";

$data   = json_decode(file_get_contents('php://input') , true);

$query   =  "INSERT INTO users(`name` , `email` , `username`) VALUES('".$data['name']."' , '".$data['email']."' , '".$data['username']."')";

$execute = mysqli_query($connection ,$query);
if($execute== true)
{
   echo "Data Has Been Inserted To Table";
} 
else
{
    echo "Failed TO Insert Data";
}



?>