<?php
include "./header.php";
include "./connection.php";
$id        = json_decode(file_get_contents('php://input') , true);
$deleteQuery = "DELETE FROM vehicles where id = '".$id."' ";
$execute     = mysqli_query($connection , $deleteQuery);

if($execute == true)
{
    $query        = "SELECT * FROM vehicles";
    $allData      = array();
    $dataexecute  = mysqli_query($connection , $query);
    while($vehicleData = mysqli_fetch_assoc($dataexecute))
    {
        $allData[]  = $vehicleData ;
    }
    echo json_encode($allData);
}





?>